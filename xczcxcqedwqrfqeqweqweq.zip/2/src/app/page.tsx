import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle,  } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback  } from "@/components/ui/avatar";
import { getAllPosts } from "@/lib/fetch";
import {format, formatDistanceToNow } from 'date-fns'; 
import Link from "next/link";
import ReactMarkdown from 'react-markdown';

export default async function Home() {
  const posts = await getAllPosts();

  return (
    <main className="min-h-screen p-4 max-w-full grid gap-4 grid-cols-1 md:grid-cols-2">
      {posts.map(post => 
        <Card key={post.id}>
          <CardHeader>
            <CardTitle>
              {post.title}
            </CardTitle>
          </CardHeader>

          <CardDescription className="flex items-center">
            <Avatar>
              {post.user.image && <AvatarImage src={post.user.image} />}
              <AvatarFallback>
                { post.user.name?.substring(0, 1) }
              </AvatarFallback>
            </Avatar>
            <span>{`${post.user.name}
            @ ${format(post.createdAt, 'dd.MM.yy, HH:mm')}
            (${formatDistanceToNow(post.createdAt, { addSuffix: true })})`}</span>
          </CardDescription>

          <CardContent>
            {post.imageUrl && (
              <img
                src={post.imageUrl}
                alt={"Post Image"}
                className="rounded-md object-cover w-full aspect-square md:w-[200px]" />
            )}
            <ReactMarkdown>
              {post.content.substring(0, 100) + '...'}
            </ReactMarkdown>
          </CardContent>
          <CardFooter>
            <Link
              href={`/post/${post.id}`}>
            </Link>
          </CardFooter>
        </Card>
      )}
    </main>
  );
}
