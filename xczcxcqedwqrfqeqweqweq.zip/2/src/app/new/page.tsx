import { auth } from '@/auth';
import { createNewPost } from '@/lib/fetch';
import { notFound, redirect } from 'next/navigation';
import React from 'react';

const NewPost = async () => {
  const session = await auth();
  if (!session) {
    notFound()
  }

  async function createPostData(formData: FormData) {
    'useServer'

    const data = {
      title: formData.get('title') as string ?? '',
      content: formData.get('content') as string ?? '',
      imageUrl: formData.get('imageUrl') as string ?? '',
      userId: session?.user?.id!,
    }

    await createNewPost(data);

    redirect('/');
  }
};

export default NewPost;