import "server-only";
import { prisma } from "./prisma";

interface NewPostData {
  title: string;
  content: string;
  imageUrl: string;
  userId: string;
}

export async function createNewPost(data: NewPostData) {
  return await prisma.post.create({ data });
}

export async function getAllPosts() {
  return await prisma.post.findMany({
    include: {
      user: {
        select: {
          name: true,
          image: true,
        },
      },
    },
    orderBy: {
      createdAt: "desc",
    },
  });
}

export async function getPostId(id: string) {
  return await prisma.post.findUnique({
    where: { id },
    include: {
      user: {
        select: {
          name: true,
          image: true,
        },
      },
    },
  });
}
