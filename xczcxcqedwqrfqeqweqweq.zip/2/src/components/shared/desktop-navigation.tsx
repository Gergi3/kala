import React from 'react'
import { ThemeSelector } from '../theme-selector';

const DesktopNavigation = () => {
  return (
    <div className="hidden lg:flex xl:gap-x-4">
      <ThemeSelector />
    </div>
  );
}

export default DesktopNavigation