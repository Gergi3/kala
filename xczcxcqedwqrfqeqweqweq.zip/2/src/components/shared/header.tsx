import { Home } from 'lucide-react'
import Link from 'next/link'
import React from 'react'
import { ThemeSelector } from '../theme-selector'
import DesktopNavigation from './desktop-navigation'

export const Header = () => {
  return (
    <header className='sticky top-0 z-50 w-full border-b border-border/40 backdrop-blur support-[backdrop-filter]:bg-background/90'>
      <nav className='mx-auto flex items-center justify-between p-4 container'>
        <Link href='/' className='shrink-0'>
          <Home />
        </Link>

        <DesktopNavigation />
      </nav>
    </header>
  )
}
